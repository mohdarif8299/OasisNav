package com.example.printvanue;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity  extends AppCompatActivity  {
    private Button pen;
    private Button card;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pen = (Button) findViewById(R.id.pen);
        card = (Button) findViewById(R.id.card);
        pen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.screen,new pen());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                //pen.setVisibility(View.GONE);
            }
        });

        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.screen,new card());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                //card.setVisibility(View.GONE);
            }
        });
    }
}
