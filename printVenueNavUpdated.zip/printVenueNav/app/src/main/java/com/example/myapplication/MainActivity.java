package com.example.myapplication;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.Toast;

import com.example.myapplication.Adapter.CustomExpendableListAdapter;
import com.example.myapplication.Fragment.BusinessCard;
import com.example.myapplication.Helper.FragmentnavigationManager;
import com.example.myapplication.Interface.NavigationManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class MainActivity extends AppCompatActivity {
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;
    private String mActivityTitle;
    private String[] items;

    private ExpandableListView expandableListView;
    private ExpandableListAdapter adapter;
    private List<String> lstTitle;
    private Map<String,List<String>> lstChild;
    private NavigationManager navigationManager;
    FragmentTransaction ft;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ft = getSupportFragmentManager().beginTransaction();

        mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        mActivityTitle = getTitle().toString();
        expandableListView = (ExpandableListView)findViewById(R.id.navlist);
        navigationManager = FragmentnavigationManager.getmInstance(this);
        /*button=findViewById(R.id.signin);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Toast.makeText(getBaseContext(),"hii",Toast.LENGTH_LONG).show();
            }
        });
*/
        initItems();

        View listHeaderView = getLayoutInflater().inflate(R.layout.nav_header,null,false);
        expandableListView.addHeaderView(listHeaderView);

        getData();

        addDrawersItem();
        setUpDrawer();

        if (savedInstanceState == null)
            selectFirstItemAsDefault();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("Anas Ansari");

        Button sign = (Button) findViewById(R.id.signin);
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(MainActivity.this, LoginSignUpMain.class);
                startActivity(intent);

            }
        });
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    private void selectFirstItemAsDefault() {
        if (navigationManager!=null){
            String firstItem = lstTitle.get(0);
            navigationManager.showFragment(firstItem);
            getSupportActionBar().setTitle(firstItem);
        }
    }

    private void setUpDrawer() {
        mDrawerToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close){
            public void onDrawerOpened(View drawerView){
                super.onDrawerOpened(drawerView);
                getSupportActionBar().setTitle("Navigation Drawer");
                invalidateOptionsMenu();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                getSupportActionBar().setTitle(mActivityTitle);
                invalidateOptionsMenu();
            }
        };

        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    private void addDrawersItem() {
        adapter = new CustomExpendableListAdapter(this, lstTitle, lstChild);
        expandableListView.setAdapter(adapter);
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                getSupportActionBar().setTitle(lstTitle.get(groupPosition).toString());
            }
        });

        expandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int groupPosition) {
                getSupportActionBar().setTitle("Anas Ansari");
            }
        });

        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                Object[] innerChild = lstChild.values().toArray();
                //lstChild.get(0)

                    if (lstTitle.get(groupPosition).equals("Business Cards")){
                        Toast.makeText(getApplicationContext(),innerChild[childPosition].toString(),Toast.LENGTH_LONG).show();
                       // Toast.makeText(getApplicationContext(),lstChild.get(groupPosition).toString(),Toast.LENGTH_LONG).show();
                        if(innerChild[childPosition].equals("Mini Business Card")){
                            Toast.makeText(getApplicationContext(),innerChild[0].toString(),Toast.LENGTH_LONG).show();
                        }
                        ft.replace(R.id.container,new BusinessCard());
                        ft.addToBackStack(null);
                        ft.commit();
                    }



                //String selectedItem = ((List) (lstChild.get(lstChild.get(groupPosition)))).get(childPosition).toString();
                //getSupportActionBar().setTitle(selectedItem);
//                for(int i=0;i<7;i++) {
//                    if (items[i].equals(lstChild.get(groupPosition))) {
//                        navigationManager.showFragment(lstChild.toString());
//                        Toast.makeText(getApplicationContext(),lstChild.toString(),Toast.LENGTH_LONG).show();
//                        break;
//                    }
//                    else
//                        throw new IllegalArgumentException("Not Supported fragment");
//                }
                mDrawerLayout.closeDrawer(GravityCompat.START);
                return false;
            }
        });
    }

    private void getData(){
       List<String> title = Arrays.asList("Products For Office","Photo_Gifts","Clothings","Business Cards","Alothings");
//        List<String> title = new ArrayList<>();
//        title.add("Business Cards");
//        title.add("Products For Office");
//        title.add("Clothings");
//        title.add("Photo_Gifts");

        List<String> productForOffice = new ArrayList();
        productForOffice.add("Stationary");
        productForOffice.add("Diaries & Organizers");

        List<String> Photo_Gifts = new ArrayList();
        Photo_Gifts.add("Calender");
        Photo_Gifts.add("Photo Album");

//        List<String> Clothings = new ArrayList();
//        Clothings.add("Men's Clothings");
//        Clothings.add("Sweatshirts");
//        Clothings.add("Wallets");

        List<String> Alothings = new ArrayList();
        Alothings.add("Men's Clothings");
        Alothings.add("Sweatshirts");

        List<String> businessCard = new ArrayList();
        //Classical Business Cards","Premium Business Card","Mini Business Card","Rounded Corner Business Card","Vertical Corner Business Card","Square Business Card","Folded Business Card"
        businessCard.add("Classical Business Cards");
        businessCard.add("Premium Business Card");
        businessCard.add("Mini Business Card");
        businessCard.add("Rounded Corner Business Card");
        businessCard.add("Vertical Corner Business Card");
        businessCard.add("Square Business Card");
        businessCard.add("Folded Business Card");


        //List<String> ProductForOffice = Arrays.asList("Stationery","Diaries & Organizers","Cand Hoolders","Pens","Office Supplies","marketing Material");
        List<String> Clothings = Arrays.asList("Men's Clothings","Sweatshirts","Wallets");
//        List<String> Accessories = Arrays.asList("Mobile Cases","Mobile Skins","Computer Accessories","Utility");
//        List<String> Photo_Gifts = Arrays.asList("Photo_Gifts For Him","Photo_Gifts For Her","Photo Photo_Gifts" );
//        List<String> HomeKitchen = Arrays.asList("Home Decor Cases","Mobile Skins","Computer Accessories");
//        List<String> GreetingsInvitation = Arrays.asList("Mobile Cases","Mobile Skins","Computer Accessories");
        lstChild = new TreeMap<>();
        lstChild.put(title.get(0),productForOffice);
        lstChild.put(title.get(1),Photo_Gifts);
        lstChild.put(title.get(2),Clothings);
        lstChild.put(title.get(3),businessCard);
        lstChild.put(title.get(4),Alothings);

        lstTitle = new ArrayList<>(lstChild.keySet());
    }

    private void initItems() {
        items = new String[]{"Android Programming","C","C++","java","java","java","java"};
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (mDrawerToggle.onOptionsItemSelected(item))
            return true;
        return super.onOptionsItemSelected(item);
    }

}
